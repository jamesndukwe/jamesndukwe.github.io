package Organisers;

import java.text.ParseException;
import java.util.List;

/*
 * This is an interface that any class that organises activities for DDADS
   must implement. This allows code flexibility as well as maintenance.
 */
/**
 *
 * @author Owner
 */
public interface Organiser {

    /*abstract method that organises the activities. This method is
    to be implemented by the class wants to organise the activities.
     */
    List<String[]> organiseActivityGroups(List<String> activities) throws ParseException;

}
