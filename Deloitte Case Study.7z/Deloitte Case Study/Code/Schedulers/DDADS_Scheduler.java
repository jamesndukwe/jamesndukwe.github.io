package Schedulers;

import Miscellaneous.Team;
import Organisers.DDADS_Organiser;
import Organisers.Organiser;
import Schedulers.DDADS_Schedule;
import Schedulers.Schedule;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/*
 * This class performs the actions needed to create a schedule. It controls
 *DDADS operations by creating schedules and their respective teams
 */
/**
 *
 * @author Owner
 */
public class DDADS_Scheduler implements Scheduler {

    /* Thid method create schedules by stamping daytimes on the activities and adding teams and their 
       activities to their schedules
     */
    @Override
    public List<Schedule> createSchedules(List<String> activities, Organiser activityOrganiser) throws ParseException {
        List<String[]> timeStampedActivityGroups = activityOrganiser.organiseActivityGroups(activities);
        final int noOfSchedules;
        final int noOfTeams = noOfSchedules = timeStampedActivityGroups.size();
        List<Team> teams = createTeams(noOfTeams);
        List<Schedule> schedules = new ArrayList<>();
        for (int i = 0; i < noOfSchedules; i++) {
            Schedule schedule = new DDADS_Schedule();
            schedule.addActivities(timeStampedActivityGroups.get(i));
            schedule.addTeam(teams.get(i));
            schedules.add(schedule);
        }

        return schedules;
    }

    // method that puts team into existence
    private List<Team> createTeams(int noOfTeams) {
        List<Team> teams = new ArrayList<>();
        for (int i = 0; i < noOfTeams; i++) {
            teams.add(new Team("Team " + (i + 1)));
        }
        return teams;
    }

}
