package Schedulers;

import Miscellaneous.Team;

/*
 * This is the class used in creating schedules.
 */
/**
 *
 * @author Owner
 */
public class DDADS_Schedule implements Schedule {

    private String[] activities;
    private Team team;

    //this method put activities into schedule
    @Override
    public void addActivities(String[] activities) {
        this.activities = activities;
    }

    //This method retrieve activeities from schedule
    @Override
    public String[] getActivities() {
        return activities;
    }

    //This method puts team into schedule
    @Override
    public void addTeam(Team team) {
        this.team = team;
    }

    //This method retrieves team from schedule
    @Override
    public Team getTeam() {
        return team;
    }

}
