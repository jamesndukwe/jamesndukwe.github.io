package FileManipulators;

import java.util.List;

/*
 *This is an interface that any class that writes the file for DDADS
  must implement. This allows code flexibility as well as maintenance.
 */
/**
 *
 * @author Owner
 * @param <T>
 */
public interface Writer<T> {

    //method to be implemented by the claas that the writes the file
    void writeFile(List<T> schedules);

}
