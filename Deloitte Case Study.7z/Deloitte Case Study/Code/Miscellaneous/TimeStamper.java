package Miscellaneous;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/*
 * This class puts day time stamp on the activities.
 */
/**
 *
 * @author Owner
 */
public class TimeStamper {
    
    private SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");

    /*this method takes the duration of activities and add them to day times
     and align them with the activities.
     */
    public List<String[]> stampTime(List<String> activities) throws ParseException {
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        int lineLength = 0;
        List<String> stampedActivities = new ArrayList<>();
        List<String[]> stamped = new ArrayList<String[]>();
        final String sprint = "15";
        String currentTimeStamp = null, preActDuration = null, preTimeStamp;

        for (String currentLine : activities) {
            if (stampedActivities.isEmpty()) {
                stampedActivities.add("09:00 am : " + currentLine);
                continue;
            }
            String lastWord, previousLine = stampedActivities.get(stampedActivities.size() - 1);
            lineLength = previousLine.split(" ").length;
            lastWord = previousLine.split(" ")[lineLength - 1];
            preActDuration = "00:" + previousLine.split(" ")[lineLength - 1].split("min")[0];
            if (lastWord.equals("sprint")) {
                preActDuration = "00:" + sprint;
            }
            preTimeStamp = previousLine.split(" ")[0];
            currentTimeStamp = getTime(preTimeStamp, preActDuration);
            if (currentTimeStamp.split(" ")[0].compareTo("12:00") >= 0
                    && currentTimeStamp.split(" ")[0].compareTo("01:00") > 0) {
                stampedActivities.add(currentTimeStamp + " : Lunch Break 60min");
                String skippedTimeStamp = getTime(currentTimeStamp, "00:60");
                stampedActivities.add(skippedTimeStamp + " : " + currentLine);
            } else if (currentTimeStamp.split(" ")[0].compareTo("03:55") >= 0
                    && currentTimeStamp.split(" ")[0].compareTo("05:00") <= 0) {
                stampedActivities.add(currentTimeStamp + " : " + currentLine);
                lineLength = currentLine.split(" ").length;
                lastWord = currentLine.split(" ")[lineLength - 1].split("min")[0];
                String currActDuration = "00:" + currentLine.split(" ")[lineLength - 1].split("min")[0];
                if (lastWord.equals("sprint")) {
                    currActDuration = "00:" + sprint;
                }
                String presentationTime = getTime(currentTimeStamp.split(" ")[0], currActDuration);
                stampedActivities.add(presentationTime + " : Staff Motivation Presentation");
                stamped.add(stampedActivities.toArray(new String[stampedActivities.size()]));

                stampedActivities.clear();

            } else {
                stampedActivities.add(currentTimeStamp + " : " + currentLine);
            }

        }
        return stamped;
    }

    //this method format the times into day time
    private String getTime(String time_1, String time_2) throws ParseException {
        Date time1 = dateFormat.parse(time_1); //date 1
        Date time2 = dateFormat.parse(time_2); // date 2
        long sum = time1.getTime() + time2.getTime();
        String timeStamp = dateFormat.format(new Date(sum));
        int hour = Integer.parseInt(timeStamp.split(":")[0]);
        String mins = timeStamp.split(":")[1];
        if (hour >= 9 && hour < 12) {
            timeStamp += " am";
        } else if ((12 - hour) == 0) {
            timeStamp += " pm";
        } else {
            timeStamp = "0" + (hour % 12) + ":" + mins + " pm";
        }
        return timeStamp;
    }
}
