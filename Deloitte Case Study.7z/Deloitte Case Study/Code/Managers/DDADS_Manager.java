package Managers;

import Schedulers.Schedule;
import Schedulers.DDADS_Scheduler;
import FileManipulators.Reader;
import FileManipulators.Writer;
import FileManipulators.File_Writer;
import FileManipulators.File_Reader;
import Organisers.DDADS_Organiser;
import java.text.ParseException;
import java.util.List;
import Schedulers.Scheduler;

/*
 * This class manages the DDADS by deligating tasks to designated parts of
  DDADS.
 */
/**
 *
 * @author Owner
 */
public class DDADS_Manager {

    private Reader<String> reader;
    private Writer<Schedule> writer;
    private Scheduler scheduler;
    private List<Schedule> schedules;

//constructor for initialization
    private DDADS_Manager() {
        this.reader = new File_Reader<>();
        this.writer = new File_Writer<>();
        this.scheduler = new DDADS_Scheduler();
    }

    //this method reads, creates and writes schedules to a file
    private void manageOperations() throws ParseException {
        List<String> activities = reader.readFile();
        schedules = scheduler.createSchedules(activities, new DDADS_Organiser());
        writer.writeFile(schedules);

    }

    /**
     * @param args the command line arguments
     * @throws java.text.ParseException
     */
    /*the starting point of DDADS execution. This method creates 
    the DDADS_Manager instance that starts managing the DDADS.
     */
    public static void main(String[] args) throws ParseException {
        final DDADS_Manager manager = new DDADS_Manager();
        manager.manageOperations();
    }

}
